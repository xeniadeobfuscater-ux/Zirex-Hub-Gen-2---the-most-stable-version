--!strict
-- Zirex Hub: all named themes resolve to black & white default
return require(script.Parent.default)
