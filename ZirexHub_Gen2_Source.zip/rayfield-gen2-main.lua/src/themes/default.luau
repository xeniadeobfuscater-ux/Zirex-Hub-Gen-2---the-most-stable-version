--!strict

-- Zirex Hub — Black & White (default)

local variables = require(script.Parent.Parent.utility.variables)

local white = Color3.fromRGB(255, 255, 255)
local soft = Color3.fromRGB(220, 220, 220)

return {
	CornerRoundness = UDim.new(0, 20),
	WindowColor = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(18, 18, 18)),
		ColorSequenceKeypoint.new(0.5, Color3.fromRGB(12, 12, 12)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(8, 8, 8)),
	}),
	ShadowColor = Color3.fromRGB(0, 0, 0),
	ElementStroke = Color3.fromRGB(48, 48, 48),
	ElementGradient = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(28, 28, 28)),
		ColorSequenceKeypoint.new(0.5, Color3.fromRGB(22, 22, 22)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(16, 16, 16)),
	}),
	ElementStrokeGradient = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(60, 60, 60)),
		ColorSequenceKeypoint.new(0.9999, Color3.fromRGB(70, 70, 70)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(60, 60, 60)),
	}),
	TabColor = white,
	TabBackground = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(38, 38, 38)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(22, 22, 22)),
	}),
	TabStroke = ColorSequence.new(white, Color3.fromRGB(180, 180, 180)),
	SliderBackground = Color3.fromRGB(36, 36, 36),
	SliderBackgroundHover = Color3.fromRGB(48, 48, 48),
	SliderProgress = ColorSequence.new(white, soft),
	SliderStroke = white,
	ActionColor = white,
	TitleFont = variables.brandFont(Enum.FontWeight.SemiBold),
	Font = variables.brandFont(Enum.FontWeight.Medium),
	ContentColor = white,

	LiveAnimation = false,

	DarkToggleOverlay = true,
	ElementTransparency = 0,
	ElementStrokeTransparency = 0,
	ElementStrokeHoverTransparency = 0,
	ElementStrokeHover = Color3.fromRGB(90, 90, 90),
	ElementCornerRadius = UDim.new(0, 12),
	ElementTextHoverColor = white,
	TitlingColor = white,

	DropdownHighlight = white,

	AccentColor = white,
	AccentStroke = soft,
	AccentGlow = 0.35,

	StatBackground = Color3.fromRGB(16, 16, 16),
	SliderHandle = white,
	PillCornerRadius = UDim.new(1, 0),

	ToggleTrack = Color3.fromRGB(0, 0, 0),
	ToggleTrackTransparency = 0.8,
	ToggleKnobOff = white,
	ToggleKnobOffTransparency = 0.7,

	FieldBackground = white,
	FieldTransparency = 0.92,
	FieldGlow = white,

	PlaceholderColor = Color3.fromRGB(140, 140, 140),
	SurfaceStroke = white,

	NeutralButton = Color3.fromRGB(24, 24, 24),
	NeutralButtonHover = Color3.fromRGB(34, 34, 34),
	NeutralButtonStroke = white,

	ErrorColor = Color3.fromRGB(185, 50, 50),
	ErrorStrokeColor = Color3.fromRGB(240, 75, 75),
}
