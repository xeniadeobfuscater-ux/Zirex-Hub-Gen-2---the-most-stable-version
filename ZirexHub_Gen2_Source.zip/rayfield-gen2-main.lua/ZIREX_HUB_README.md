# Zirex Hub (Rayfield Gen 2 source, rebranded)

## What changed
- **Name:** Zirex Hub (window defaults, loader text)
- **Icon:** `rbxassetid://118458336329283`
- **Theme:** Black & White only (toggles, sliders, tabs, accents are white)
- **Loader:** Centered splash — logo + "Zirex Hub" + Loading...

## How to combine into one file (for executors)

This repo is **modular** (many `.luau` files). Executors need **one** script.

### Option A — Build with official tools (recommended)
On a machine with [Rokit](https://github.com/rojo-rbx/rokit) + Lune:

```bash
cd rayfield-gen2-main.lua   # or this folder
rokit install
make bundle
```

Output is usually `build/bundled.luau`. Host that file on GitHub raw and load with:

```lua
loadstring(game:HttpGet("YOUR_RAW_URL"))()
```

### Option B — Rojo + Studio
Open `default.project.json` with Rojo, sync into Studio, then use your usual packer/bundler.

### Option C — Already have a single-file build
If you already use `ZirexHub_RayfieldPlus.luau` on GitHub, keep using that for runtime.
This folder is the **editable source** matching those branding choices.

## Quick test (after bundle)

```lua
local ZirexHub = loadstring(game:HttpGet("YOUR_BUNDLED_RAW_URL"))()
local Window = ZirexHub:CreateWindow({
    name = "Zirex Hub",
    subtitle = "Test",
    showName = "Zirex Hub",
    showIcon = 118458336329283,
    sidebarLayout = true,
    theme = "default", -- black & white
})
```
